import HTMLView from './HTMLView';

export default HTMLView;
